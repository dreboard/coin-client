create
    definer = root@localhost procedure CollectionGetCoinInvestment(IN u_id int, IN c_id int)
    comment 'Total Investments By Coin'
BEGIN
    SELECT COALESCE(sum(cp.purchasePrice), 0.00) AS invested
    FROM collected_purchase cp
             INNER JOIN collected co ON co.id = cp.collected_id
    WHERE co.userID = u_id
      AND co.coinID = c_id;
  END;

