create
    definer = root@localhost procedure CoinGetColorCountByTypeCollected(IN color varchar(100), IN type varchar(100), IN id int(100))
BEGIN
    DECLARE designTypeCount INT(11);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
      GET DIAGNOSTICS CONDITION 1
      @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
      SELECT @p1, @p2;
    END;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET designTypeCount = 0;

    SELECT COUNT(*) FROM collection
      INNER JOIN coins ON collection.coinID = coins.coinID
    WHERE collection.userID = id AND coins.coinType = type
          AND collection.color = color;
  END;

