create
    definer = root@localhost procedure DesignTypeGetAll(IN dt varchar(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'Design type not found';
    SELECT * FROM coin_orm.coins WHERE coins.designType = dt AND coins.designType != 'None'
    ORDER BY coinName ASC;
  END;

