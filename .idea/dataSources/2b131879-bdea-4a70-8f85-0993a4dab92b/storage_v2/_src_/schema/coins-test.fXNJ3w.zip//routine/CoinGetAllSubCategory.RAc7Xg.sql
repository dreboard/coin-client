create
    definer = root@localhost procedure CoinGetAllSubCategory(IN c_sub varchar(100)) comment 'Get all SubCategory coins'
BEGIN
    SELECT c.id, c.coinName, ct.coinType, c.coinYear, c.coinVersion
    FROM coins c
             INNER JOIN cointypes ct ON c.cointypes_id = ct.id
             INNER JOIN coincategories cc ON cc.id = c.coincats_id
    WHERE coinSubCategory = c_sub
    ORDER BY c.coinYear;
END;

