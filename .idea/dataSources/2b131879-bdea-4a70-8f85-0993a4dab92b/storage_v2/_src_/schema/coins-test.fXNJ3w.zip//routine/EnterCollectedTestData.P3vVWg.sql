create
    definer = root@localhost procedure EnterCollectedTestData(IN collectID varchar(50)) comment 'collected coin data.'
BEGIN
	INSERT INTO `collected_img` (`id`, `collected_id`, `url`, `saved`) VALUES (NULL, collectID, '../img/noPic.jpg', current_timestamp());
	INSERT INTO `collected_error` (`id`, `collected_id`, `damaged`, `offCenter`, `multipleStrike`, `secondStrike`, `broadstrike`, `partialCollar`, `bondedPlanchets`, `matedPair`, `doubleDenom`, `indentPercent`, `clippedPlanchet`, `mule`, `rotated`, `dieCrack`, `machineDouble`, `brockage`, `strikeThru`, `wrongPlanchet`, `wrongMetal`, `blisters`, `plating`, `saved`) VALUES (NULL, '2460', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'No', 'Yes', 'No', 'No', 'No', 'No', 'No', 'No', 'No', current_timestamp());
	INSERT INTO `collected_traildie` (`id`, `collected_id`, `trailDie`, `trailDieStrength`, `trailDieDeviation`, `trailDieNumber`, `trailDieDirection`, `saved`) VALUES (NULL, collectID, '1', 'weak', 'light', '1982P-1DEO-001T ', 'west', current_timestamp());
	INSERT INTO `collected_purchase` (`id`, `collected_id`, `purchaseFrom`, `purchaseDate`, `purchasePrice`, `ebaySellerID`, `shopName`, `shopUrl`, `showName`, `showCity`, `saved`) VALUES (NULL, collectID, 'Store', current_timestamp(), '100.00', 'None', 'None', 'None', 'None', 'None', current_timestamp());
	INSERT INTO `collected_variety` (`id`, `collected_id`, `ddo`, `ddr`, `rpm`, `omm`, `mms`, `odv`, `rdv`, `red`, `imm`, `dmr`, `mdr`, `mdo`, `rpd`, `rpmDirection`, `mintmarkStage`, `wddr`, `wddo`, `saved`) VALUES (NULL, collectID, 'None', 'DDR-001', 'None', 'None', 'None', 'None', 'None', 'None', 'None', 'DMR-006', 'None', 'None', 'None', 'None', 'None', 'None', 'None', current_timestamp());
	INSERT INTO `collected_damage` (`id`, `collected_id`, `damaged`, `holed`, `cleaned`, `altered`, `scratched`, `pvc`, `corrosion`, `bent`, `plugged`, `polished`, `saved`) VALUES (NULL, collectID, '1', '0', '1', '0', '1', '0', '0', '0', '0', '0', current_timestamp());

  END;

