create
    definer = root@localhost procedure MaintUpdateInitialCoinTypeField() comment 'Reset coinType initial year'
BEGIN
    DECLARE coinTypeID INT;
    DECLARE v_finished INTEGER DEFAULT 0;
    DECLARE coinTypeCusor CURSOR FOR SELECT id FROM `cointypes`;
    DECLARE CONTINUE HANDLER
        FOR NOT FOUND SET v_finished = 1;

    OPEN coinTypeCusor;
    get_coinType:
    LOOP

        FETCH coinTypeCusor INTO coinTypeID;
        IF v_finished = 1 THEN
            LEAVE get_coinType;
        END IF;

        UPDATE `cointypes`
        SET `initial` = SUBSTRING(dates,1, 4)
        WHERE id = coinTypeID;

    END LOOP get_coinType;
    CLOSE coinTypeCusor;

END;

