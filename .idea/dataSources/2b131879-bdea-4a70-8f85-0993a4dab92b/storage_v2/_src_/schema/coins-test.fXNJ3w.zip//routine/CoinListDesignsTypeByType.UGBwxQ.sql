create
    definer = root@localhost procedure CoinListDesignsTypeByType(IN c_type int) comment 'Get design types by coin Type'
BEGIN
    SELECT DISTINCT(designType) FROM `coins` WHERE designType <> 'none' AND cointypes_id = c_type;
END;

