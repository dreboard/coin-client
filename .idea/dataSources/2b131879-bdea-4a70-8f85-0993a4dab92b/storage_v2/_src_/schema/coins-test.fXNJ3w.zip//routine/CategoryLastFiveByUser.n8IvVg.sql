create
    definer = root@localhost procedure CategoryLastFiveByUser(IN cat varchar(50), IN id int(10))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
      GET DIAGNOSTICS CONDITION 1
      @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
      SELECT @p1, @p2;
    END;

    SELECT * FROM collection
      INNER JOIN coins ON coins.coinID = collection.coinID
    WHERE coins.coinCategory = cat AND collection.userID = id
    ORDER BY collection.enterDate DESC
    LIMIT 5;
  END;

