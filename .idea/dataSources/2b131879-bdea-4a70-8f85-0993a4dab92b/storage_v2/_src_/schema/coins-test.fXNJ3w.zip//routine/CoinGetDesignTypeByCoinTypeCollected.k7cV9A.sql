create
    definer = root@localhost procedure CoinGetDesignTypeByCoinTypeCollected(IN design varchar(100), IN id int(100))
BEGIN
    DECLARE designTypeCount INT(11);
    #DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'design collected type not found';
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
      GET DIAGNOSTICS CONDITION 1
      @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
      SELECT @p1, @p2;
    END;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET designTypeCount = 0;

    SELECT DISTINCT(coins.designType) AS designType,
      #coinGetDesignTypeByCoinTypeCollectedCount(design, id) AS designTypeCount
      (SELECT COUNT(coins.designType)
       FROM coin_orm.collection
         INNER JOIN coin_orm.coins ON collection.coinID = coins.coinID
       WHERE collection.userID = id
             AND coins.designType = design) AS designTypeCount

    FROM coin_orm.collection
    INNER JOIN coin_orm.coins ON collection.coinID = coins.coinID
    WHERE coins.designType = design AND collection.userID = id
    ORDER BY coins.coinYear ASC;

  END;

