create
    definer = root@localhost procedure MintSetGetByID(IN c_id int) comment 'Get MintSet by id.'
BEGIN
    PREPARE dynamic_statement FROM
        'SELECT mintsetID, setName, coins, coinYear,
            SUM(LENGTH(coins) - LENGTH(REPLACE(coins, '','', '''')) + 1) as num
        FROM mintset WHERE mintsetID = ? LIMIT 1';
    EXECUTE dynamic_statement USING c_id;
    DEALLOCATE PREPARE dynamic_statement;
END;

