create
    definer = root@localhost procedure CoinGetAllFromYear(IN cy int) comment 'Get coins all same year.'
BEGIN
    PREPARE dynamic_statement FROM
        'SELECT id, coinName, coinType, coinYear
        FROM coins
        WHERE coins.coinYear = ? ORDER BY coins.denomination';
    EXECUTE dynamic_statement USING cy;
    DEALLOCATE PREPARE dynamic_statement;
END;

