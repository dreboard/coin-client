create
    definer = root@localhost procedure _TestCoin(IN c_id int)
BEGIN
  DECLARE EXIT HANDLER FOR SQLEXCEPTION, SQLWARNING
  BEGIN
    ROLLBACK;
    RESIGNAL;
  END;  
  
  IF NOT EXISTS(SELECT id, coinName FROM `coins` WHERE `coins`.`id` = c_id) THEN
    SELECT id, coinName FROM `coins` WHERE `coins`.`id` = 4003;
  END IF;  
END;

