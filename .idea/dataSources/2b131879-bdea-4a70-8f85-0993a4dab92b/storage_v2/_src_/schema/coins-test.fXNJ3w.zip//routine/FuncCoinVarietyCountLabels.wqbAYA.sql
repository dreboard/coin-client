create
    definer = root@localhost function FuncCoinVarietyCountLabels(c_id varchar(30), v_label varchar(7)) returns int
    comment 'Get count of different design types'
BEGIN
    DECLARE designCount INT;
    SELECT COUNT(cv.coin_id)
    INTO designCount
    FROM coins_variety cv
    WHERE cv.coin_id = c_id AND LEFT(cv.label, 3) = v_label;
    RETURN designCount;
END;

