create
    definer = root@localhost function CategoryGetCoinTypesCollected(p_cat varchar(20)) returns int
BEGIN
    DECLARE typesCollected INT;

    SELECT COUNT(DISTINCT coins.coinType) INTO typesCollected FROM collection
      INNER JOIN coins ON collection.coinID = coins.coinID
    WHERE coins.coinCategory = p_cat;

    RETURN (typesCollected);
  END;

