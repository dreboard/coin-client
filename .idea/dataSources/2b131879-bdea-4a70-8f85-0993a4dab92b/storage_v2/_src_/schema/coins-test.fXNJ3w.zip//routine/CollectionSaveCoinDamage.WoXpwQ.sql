create
    definer = root@localhost procedure CollectionSaveCoinDamage(IN co_id int, IN c_holed int, IN c_cleaned int,
                                                                IN c_altered int, IN c_scratched int, IN c_pvc int,
                                                                IN c_corrosion int, IN c_bent int, IN c_plugged int)
    comment 'Save coin DAMAGE'
BEGIN
    INSERT INTO `collected_damage`
        (`id`, `collected_id`, `holed`, `cleaned`, `altered`, `scratched`, `pvc`, `corrosion`, `bent`, `plugged`, `saved`)
    VALUES
        (NULL, co_id, c_holed, c_cleaned, c_altered, c_scratched, c_pvc, c_corrosion, c_bent, c_plugged, current_timestamp());
END;

