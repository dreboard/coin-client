create view viewseatedlibertytypes as
select distinct `c`.`coinType` AS `coinType`
from `coins-test`.`coins` `c`
where `c`.`design` = 'Seated Liberty'
order by `c`.`denomination`;

