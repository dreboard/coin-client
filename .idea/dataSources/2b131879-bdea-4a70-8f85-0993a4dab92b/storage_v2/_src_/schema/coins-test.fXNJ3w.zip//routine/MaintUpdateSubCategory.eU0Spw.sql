create
    definer = root@localhost procedure MaintUpdateSubCategory() comment 'Get all SubCategory coins'
BEGIN
    IF EXISTS(SELECT * FROM coins WHERE coinSubCategory IS NULL)
    THEN
        UPDATE `coins2` SET `coinSubCategory` = 'None' WHERE `coinSubCategory` IS NULL;
    END IF;
END;

