create
    definer = root@localhost procedure CommemorativeGetVersionTypes(IN type varchar(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'commemoratives not found';
    SELECT coinVersion FROM coins WHERE coinType = type ORDER BY denomination DESC;
  END;

