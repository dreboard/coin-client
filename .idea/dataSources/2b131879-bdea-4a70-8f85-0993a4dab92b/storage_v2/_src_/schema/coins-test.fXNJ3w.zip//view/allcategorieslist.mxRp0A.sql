create definer = root@localhost view allcategorieslist as
select distinct `coin_orm`.`coins`.`coinCategory` AS `coinCategory`
from `coin_orm`.`coins`
order by `coin_orm`.`coins`.`denomination` desc;

