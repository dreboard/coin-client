create
    definer = root@localhost procedure CoinListMintMarkTypeFromYear(IN c_year int, IN c_type int)
BEGIN
    SELECT DISTINCT(c.mintMark) FROM coins c
    INNER JOIN cointypes ct ON c.cointypes_id = ct.id
    WHERE c.coinYear = c_year AND ct.id = c_type;
  END;

