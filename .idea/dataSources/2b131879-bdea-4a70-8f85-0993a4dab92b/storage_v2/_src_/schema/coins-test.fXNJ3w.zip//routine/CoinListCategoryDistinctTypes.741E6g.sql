create
    definer = root@localhost procedure CoinListCategoryDistinctTypes(IN c_cat int) comment 'Get all types by category'
BEGIN
    SELECT ct.coinType, ct.id,
      FuncCoinTypeCountByCategory(c_cat) AS typeCount
    FROM cointypes ct
    WHERE ct.coincats_id = c_cat  AND LEFT(ct.coinType, 5) != 'Mixed'
    ORDER BY ct.initial;
  END;

