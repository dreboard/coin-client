create
    definer = root@localhost procedure ReplicateCoinsTable() comment 'Replicate Coins Table.'
BEGIN
    DROP TABLE IF EXISTS `coins2`;
    CREATE TABLE IF NOT EXISTS `coins-test`.`coins2` LIKE `coins-test`.`coins`;
     INSERT `coins-test`.`coins2` SELECT * FROM `coins-test`.`coins`;
    INSERT INTO error_log (error_num, error_message) VALUES ('e1000', 'ReplicateCoinsTable event');
  END;

