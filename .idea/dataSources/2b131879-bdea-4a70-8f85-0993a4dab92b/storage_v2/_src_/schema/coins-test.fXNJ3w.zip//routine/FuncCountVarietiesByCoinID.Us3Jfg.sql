create
    definer = root@localhost function FuncCountVarietiesByCoinID(c_id int, c_variety varchar(30)) returns int
    comment 'Get count of variety type by coinID'
BEGIN
    DECLARE varietyCount INT;
    SELECT COUNT(cv.variety)
    INTO varietyCount
    FROM coins_variety cv
    WHERE cv.coin_id = c_id
      AND cv.variety = c_variety;
    RETURN varietyCount;
END;

