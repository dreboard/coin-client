create
    definer = root@localhost procedure CategoryUserTotalInvestmentSumFrom(IN id int, IN cat varchar(100), IN purchaseFrom varchar(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT '0';
    SELECT COALESCE(sum(purchasePrice), 0.00)
    FROM coin_orm.collection
    INNER JOIN coin_orm.coins ON collection.coinID = coins.coinID
    WHERE collection.userID = id
    AND coins.coinCategory = cat
    AND collection.purchaseFrom = purchaseFrom;
  END;

