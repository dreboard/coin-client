create definer = root@localhost view viewclassictypes as
select distinct `ct`.`coinType` AS `coinType`
from (`coins-test`.`cointypes` `ct`
         join `coins-test`.`coincategories` `cc` on (`cc`.`id` = `ct`.`coincats_id`))
where `ct`.`id` in (5, 21, 22, 10, 15, 38, 64)
order by `ct`.`denomination`;

