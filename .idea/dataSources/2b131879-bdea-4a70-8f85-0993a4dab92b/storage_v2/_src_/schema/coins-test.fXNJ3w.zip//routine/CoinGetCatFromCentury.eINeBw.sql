create
    definer = root@localhost procedure CoinGetCatFromCentury(IN cent int) comment 'Get all categories for this century'
BEGIN
    PREPARE dynamic_statement FROM
        'SELECT DISTINCT(coins.coinCategory) FROM coins WHERE century =  ? ORDER BY coins.denomination';
    EXECUTE dynamic_statement USING cent;
    DEALLOCATE PREPARE dynamic_statement;
END;

