create
    definer = root@localhost procedure SelectCollectedTestData(IN collectID varchar(50), IN id int(10))
    comment 'Get users collected coin.'
BEGIN
    -- TO GET ALL TYPE
	SELECT * FROM collected cc

	INNER JOIN coins c
	ON c.id = cc.coinID

	INNER JOIN cointypes cty
	ON cty.id = c.cointypes_id

	INNER JOIN collected_img ci
	ON ci.collected_id = cc.id

	INNER JOIN collected_trailDie ct
	ON ct.collected_id = cc.id

	INNER JOIN collected_damage cd
	ON cd.collected_id = cc.id

	INNER JOIN collected_error ce
	ON ce.collected_id = cc.id

	INNER JOIN collected_purchase cp
	ON cp.collected_id = cc.id

	INNER JOIN collected_variety cv
	ON cv.collected_id = cc.id
    WHERE cc.id = collectID AND cc.userID = id;
  END;

