create
    definer = root@localhost procedure migrate_charset_to_utf8()
BEGIN
    DECLARE done TINYINT DEFAULT 0;
    DECLARE curr_table VARCHAR(64);

    DECLARE table_cursor CURSOR FOR
    SELECT T.table_name
      FROM information_schema.TABLES T
      WHERE T.TABLE_TYPE = 'BASE TABLE' AND
        T.TABLE_SCHEMA = 'coins-test';
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    OPEN table_cursor;

    table_loop: LOOP
      FETCH table_cursor INTO curr_table;
      IF done THEN
        LEAVE table_loop;
      END IF;

      # Convert table data(columns) charset
      SET @sql_str1 = CONCAT("ALTER TABLE ", curr_table, " CONVERT TO CHARACTER SET utf8 COLLATE utf8_general_ci");
      PREPARE stmt1 FROM @sql_str1;
      EXECUTE stmt1;
      DEALLOCATE PREPARE stmt1;

      # Set table's default charset e.g for new columns added
      SET @sql_str2 = CONCAT("ALTER TABLE ", curr_table, " CHARACTER SET utf8 COLLATE utf8_general_ci");
      PREPARE stmt2 FROM @sql_str2;
      EXECUTE stmt2;
      DEALLOCATE PREPARE stmt2;

    END LOOP table_loop;

    CLOSE table_cursor;
  END;

