create
    definer = root@localhost procedure CoinGetAllProofBullionTypeFromYear(IN c_year int, IN c_type int)
    comment 'Get All Proof Bullion coins From a Year by type'
BEGIN
    SELECT coins.id, coins.coinName, coins.coinType, coins.coinYear, coins.coinVersion
        FROM coins
    INNER JOIN coincategories cc ON cc.id = coins.coincats_id
    INNER JOIN cointypes ct ON coins.cointypes_id = ct.id
        WHERE coins.coinYear = c_year
          AND coins.coinMetal IN ('Gold', 'Platinum', 'Palladium')
          AND coins.strike IN ('Proof', 'Reverse Proof')
    AND coins.cointypes_id = c_type
    ORDER BY cc.denomination;

END;

