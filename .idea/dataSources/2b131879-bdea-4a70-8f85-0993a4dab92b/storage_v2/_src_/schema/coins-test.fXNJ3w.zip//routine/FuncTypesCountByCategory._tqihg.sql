create
    definer = root@localhost function FuncTypesCountByCategory(c_cat varchar(20)) returns int
    comment 'Get coins year list.'
BEGIN
    DECLARE c_types VARCHAR(30);
    IF c_cat IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Category cant be blank';
    END IF;
    SELECT COUNT(coinType)
    INTO c_types
    FROM cointypes
    WHERE coinCategory = c_cat;
    RETURN c_types;
END;

