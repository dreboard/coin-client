create definer = root@localhost view viewallcategorieslist as
select `coins-test`.`coincategories`.`id` AS `id`, `coins-test`.`coincategories`.`coinCategory` AS `coinCategory`
from `coins-test`.`coincategories`
where `coins-test`.`coincategories`.`id` <> 29
order by `coins-test`.`coincategories`.`denomination`;

