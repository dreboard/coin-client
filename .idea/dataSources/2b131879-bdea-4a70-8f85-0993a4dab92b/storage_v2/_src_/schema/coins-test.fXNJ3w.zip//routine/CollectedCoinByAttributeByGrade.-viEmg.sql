create
    definer = root@localhost procedure CollectedCoinByAttributeByGrade(IN c_id int(10), IN u_id int(10))
    comment 'Get colors count by coin idr'
BEGIN
    SELECT
           DISTINCT co.coinGrade,
           CONCAT('PR-70 ', FuncCollectionCountCoinByGrade(5, 2111, 'PR-70'))  AS pr70,
           CONCAT('PR-69 ', FuncCollectionCountCoinByGrade(5, 2111, 'PR-69'))  AS pr69
	FROM collected co
    INNER JOIN coins c ON c.id = co.coinID
	WHERE co.coinID = c_id AND co.userID = u_id GROUP BY co.coinGrade ;
  END;

