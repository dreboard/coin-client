create
    definer = root@localhost procedure CoinGetAllStrikeFromDecadeList(IN c_year int, IN c_strike varchar(20))
    comment 'Get coins all same decade 195x.'
BEGIN
    SELECT c.id, c.mintMark, c.coinYear, cc.coinCategory, ct.coinType, c.coinName, c.coinVersion, c.coinMetal, c.strike, cc.denomination
        FROM coins c
            INNER JOIN cointypes ct ON ct.id = c.cointypes_id
            INNER JOIN coincategories cc ON cc.id = c.coincats_id
    WHERE coinYear LIKE CONCAT(SUBSTRING(c_year,1, 3), '%') AND c.strike = c_strike
    ORDER BY cc.denomination, c.coinYear;
END;

