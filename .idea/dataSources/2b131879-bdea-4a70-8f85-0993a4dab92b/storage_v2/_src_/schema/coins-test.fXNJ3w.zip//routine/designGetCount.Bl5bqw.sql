create
    definer = root@localhost function designGetCount(design varchar(20)) returns int
BEGIN
    DECLARE designsCollected INT;

    SELECT COUNT(DISTINCT coins.coinVersion) INTO designsCollected FROM coins
    WHERE coins.coinVersion = design;

    RETURN designsCollected;
  END;

