create
    definer = root@localhost procedure CoinListTypeFromCoinVersion(IN c_ver varchar(100))
    comment 'Get Type From coinVersion'
BEGIN
    SELECT DISTINCT(ct.coinType)
    FROM cointypes ct
             INNER JOIN coins c ON ct.id = c.cointypes_id
    WHERE c.coinVersion = c_ver
    LIMIT 1;
END;

