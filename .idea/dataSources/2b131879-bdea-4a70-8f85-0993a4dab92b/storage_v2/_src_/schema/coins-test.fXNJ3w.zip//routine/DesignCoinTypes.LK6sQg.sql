create
    definer = root@localhost procedure DesignCoinTypes(IN design varchar(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'Design not found';
    SELECT DISTINCT( coinType ) FROM coins WHERE coins.design = design
    ORDER BY denomination ASC;
  END;

