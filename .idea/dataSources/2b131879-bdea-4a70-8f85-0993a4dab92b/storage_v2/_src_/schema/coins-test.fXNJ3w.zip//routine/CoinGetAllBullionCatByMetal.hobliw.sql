create
    definer = root@localhost procedure CoinGetAllBullionCatByMetal(IN c_cat int, IN c_metal varchar(20))
    comment 'Get All Bullion coins by category and metal'
BEGIN
        SELECT c.id, c.coinName, c.coinType, c.coinYear, c.coinVersion, c.coinMetal
        FROM coins c
            INNER JOIN coincategories cc ON cc.id = c.coincats_id
    WHERE c.coinMetal = c_metal AND c.coincats_id = c_cat
    ORDER BY cc.denomination;
END;

