create
    definer = root@localhost procedure CoinGetAllCategoryFromYear(IN c_year int) comment 'Get Category From Year (1922)'
BEGIN
    SELECT DISTINCT(cc.coinCategory) as catYear
        FROM coincategories cc
            INNER JOIN coins c ON c.coincats_id = cc.id
    WHERE c.coinYear  = c_year
    ORDER BY cc.denomination;
END;

