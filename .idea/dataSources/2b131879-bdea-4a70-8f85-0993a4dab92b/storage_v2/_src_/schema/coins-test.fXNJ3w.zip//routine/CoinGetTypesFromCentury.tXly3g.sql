create
    definer = root@localhost procedure CoinGetTypesFromCentury(IN cent int)
    comment 'Get all categories for this century'
BEGIN
    PREPARE dynamic_statement FROM
        'SELECT DISTINCT(coins.coinType) FROM coins WHERE century =  ? ORDER BY coins.denomination';
    EXECUTE dynamic_statement USING cent;
    DEALLOCATE PREPARE dynamic_statement;
END;

