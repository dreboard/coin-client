create
    definer = root@localhost procedure CoinGetDistinctVarietyByCoinId(IN c_id int) comment 'Get all labels by coin id'
BEGIN
    SELECT DISTINCT variety FROM `coins_variety` WHERE coin_id = c_id;
END;

