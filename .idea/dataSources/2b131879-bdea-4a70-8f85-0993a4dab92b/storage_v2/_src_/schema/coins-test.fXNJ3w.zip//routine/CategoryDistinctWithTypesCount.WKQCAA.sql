create
    definer = root@localhost procedure CategoryDistinctWithTypesCount(IN cat varchar(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'Types counts not found';
    SELECT DISTINCT coinCategory,
      categoryGetCoinTypesCount(cat) AS typeCount
    FROM coin_orm.coins
    WHERE coins.coinCategory = cat;
  END;

