create
    definer = root@localhost procedure CoinGetAllLabelsByCoinId(IN c_id int) comment 'Get all labels by coin id'
BEGIN
    SELECT cv.id, cv.sub_type, cv.variety, cv.label, cv.designation
    FROM coins_variety cv
             INNER JOIN coins c ON c.id = cv.coin_id
    WHERE coin_id = c_id
    ORDER BY CASE
                 WHEN c.cointypes_id = 33 THEN udf_NaturalSortFormat(cv.label, 19, ".")
                 ELSE cv.variety
                 END ASC;
END;

