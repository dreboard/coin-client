create
    definer = root@localhost procedure FindSearchItem(IN searchItem varchar(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'Item not found';
    SELECT * FROM coins
    WHERE
      (
        coinName LIKE CONCAT('%', searchItem , '%')
        OR
        coinType LIKE CONCAT('%', searchItem, '%')
        OR
        coins.coinVersion LIKE CONCAT('%', searchItem, '%')
        OR
        design LIKE CONCAT('%', searchItem, '%')
      )
    ORDER BY coinName ASC;
  END;

