create definer = root@localhost view viewpalladiumcategories as
select distinct `cc`.`coinCategory` AS `coinCategory`
from (`coins-test`.`coins` `c`
         join `coins-test`.`coincategories` `cc` on (`cc`.`id` = `c`.`coincats_id`))
where `c`.`coinMetal` = 'Palladium'
  and `cc`.`id` <> 29
order by `cc`.`denomination`;

