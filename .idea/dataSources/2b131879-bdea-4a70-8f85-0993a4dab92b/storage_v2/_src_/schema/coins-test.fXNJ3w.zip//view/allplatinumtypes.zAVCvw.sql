create definer = root@localhost view allplatinumtypes as
select distinct `coin_orm`.`coins`.`coinType` AS `coinType`
from `coin_orm`.`coins`
where `coin_orm`.`coins`.`coinMetal` = 'Platinum'
order by `coin_orm`.`coins`.`denomination` desc;

