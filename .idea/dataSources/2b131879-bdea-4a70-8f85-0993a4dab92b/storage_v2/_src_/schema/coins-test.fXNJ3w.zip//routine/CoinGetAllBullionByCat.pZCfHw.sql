create
    definer = root@localhost procedure CoinGetAllBullionByCat(IN c_cat int) comment 'Get All Bullion category coins'
BEGIN
         SELECT * FROM ViewCoinQuery c-- c.id, c.coinName, c.coinType, c.coinYear, c.coinVersion, c.coinMetal, c.coincats_id FROM coins c
            INNER JOIN coincategories cc ON cc.id = c.coincats_id
    WHERE c.coincats_id = c_cat AND c.coinMetal IN ('Gold', 'Platinum', 'Palladium')
    ORDER BY cc.denomination;
END;

