create
    definer = root@localhost function coinGetDesignTypeByCoinTypeCollectedCount(design varchar(20), id int(100)) returns int
BEGIN
    DECLARE typesCollected INT;

    SELECT COUNT(coins.designType) INTO typesCollected
    FROM coin_orm.collection
      INNER JOIN coin_orm.coins ON collection.coinID = coins.coinID
    WHERE collection.userID = id
          AND coins.designType = design;

    IF(typesCollected = 0) THEN
      SET typesCollected = 0;
    END IF;

    RETURN typesCollected;
  END;

