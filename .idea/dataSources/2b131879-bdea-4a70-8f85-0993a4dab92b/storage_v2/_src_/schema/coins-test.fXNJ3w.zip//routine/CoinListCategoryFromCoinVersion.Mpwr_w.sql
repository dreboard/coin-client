create
    definer = root@localhost procedure CoinListCategoryFromCoinVersion(IN c_ver varchar(100))
    comment 'Get Category From coinVersion'
BEGIN
    SELECT DISTINCT(cc.coinCategory)
    FROM coincategories cc
             INNER JOIN coins c ON cc.id = c.coincats_id
    WHERE c.coinVersion = c_ver
    LIMIT 1;

END;

