create definer = root@localhost view commemorativecategoriesview as
select distinct `coins-test`.`coins`.`coinCategory` AS `coinCategory`
from `coins-test`.`coins`
where `coins-test`.`coins`.`commemorative` = 1
order by `coins-test`.`coins`.`denomination` desc;

