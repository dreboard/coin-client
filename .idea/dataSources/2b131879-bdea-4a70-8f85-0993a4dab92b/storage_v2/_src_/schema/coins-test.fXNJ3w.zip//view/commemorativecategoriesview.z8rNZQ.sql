create definer = root@localhost view commemorativecategoriesview as
select distinct `coin_orm`.`coins`.`coinCategory` AS `coinCategory`
from `coin_orm`.`coins`
where `coin_orm`.`coins`.`commemorative` = 1
order by `coin_orm`.`coins`.`denomination` desc;

