create definer = root@localhost view viewcoinquery as
select `c`.`id`           AS `id`,
       `c`.`coinName`     AS `coinName`,
       `c`.`cointypes_id` AS `cointypes_id`,
       `c`.`coincats_id`  AS `coincats_id`,
       `c`.`coinYear`     AS `coinYear`,
       `c`.`coinVersion`  AS `coinVersion`,
       `c`.`coinMetal`    AS `coinMetal`
from `coins-test`.`coins` `c`;

