create
    definer = root@localhost procedure CommemorativeGetTypes()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'commemoratives not found';
    SELECT * FROM commemorativeTypesView;
  END;

