create
    definer = root@localhost procedure CoinListAllBullionCatsFromYear(IN c_year int)
    comment 'Get All Bullion coin types From a Year'
BEGIN
        SELECT DISTINCT(cc.coinCategory)
        FROM coins c
            INNER JOIN coincategories cc ON cc.id = c.coincats_id
    WHERE c.coinYear = c_year AND c.coinMetal IN ('Gold', 'Platinum', 'Palladium')
    ORDER BY cc.denomination;
END;

