create
    definer = root@localhost procedure DesignGetAll(IN design varchar(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'Design not found';
    SELECT * FROM coin_orm.coins WHERE coins.design = design
    ORDER BY coinName ASC;
  END;

