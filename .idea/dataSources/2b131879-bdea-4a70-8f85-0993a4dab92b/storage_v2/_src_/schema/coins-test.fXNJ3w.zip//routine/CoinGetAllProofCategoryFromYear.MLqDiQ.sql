create
    definer = root@localhost procedure CoinGetAllProofCategoryFromYear(IN c_year int, IN c_cat int)
    comment 'Get Commemorative all same year.'
BEGIN
     SELECT c.id, c.coinName, ct.coinType, c.coinYear, c.coinVersion
        FROM coins c
            INNER JOIN cointypes ct ON c.cointypes_id = ct.id
        INNER JOIN coincategories cc ON cc.id = c.coincats_id
        WHERE c.coinYear = c_year AND c.coincats_id = c_cat AND c.strike IN ('Proof', 'Reverse Proof')  ORDER BY cc.denomination, c.cointypes_id;
END;

