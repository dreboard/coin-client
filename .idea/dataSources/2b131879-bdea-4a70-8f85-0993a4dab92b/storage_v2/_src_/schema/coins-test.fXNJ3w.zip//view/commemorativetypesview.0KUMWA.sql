create definer = root@localhost view commemorativetypesview as
select distinct `coin_orm`.`coins`.`coinType` AS `coinType`
from `coin_orm`.`coins`
where `coin_orm`.`coins`.`commemorative` = 1
order by `coin_orm`.`coins`.`denomination` desc;

