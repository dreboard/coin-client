create
    definer = root@localhost procedure GetAllCoinVarietyTypeByID(IN c_id int(10))
    comment 'Get variety with same coinID.'
BEGIN
      SELECT 
         CASE
            WHEN cv.sub_type != 'None' THEN CONCAT(c.coinName, " ", COALESCE(cv.sub_type, ''))
            ELSE c.coinName
        END AS coinName,             
             cv.label, cv.designation
      FROM coins_variety cv
               INNER JOIN coins c ON c.id = cv.coin_id
      WHERE cv.coin_id = c_id
      ORDER BY udf_NaturalSortFormat(cv.label, 10, ".");
  END;

