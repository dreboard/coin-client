create
    definer = root@localhost procedure DesignCoinCategory(IN design varchar(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'Design not found';
    SELECT DISTINCT( coinCategory ) FROM coins WHERE coins.design = design
    ORDER BY denomination ASC;
  END;

