create
    definer = root@localhost procedure CoinsGetBieCoins(IN cat varchar(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT '0';
    SELECT *
    FROM lincolnWheatBieCoinsView;
  END;

