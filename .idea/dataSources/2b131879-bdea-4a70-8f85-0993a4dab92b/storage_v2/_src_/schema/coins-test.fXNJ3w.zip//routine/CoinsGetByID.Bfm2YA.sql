create
    definer = root@localhost procedure CoinsGetByID(IN c_id int) comment 'Get coin by id.'
BEGIN
    PREPARE dynamic_statement FROM
        'SELECT c.id, c.mintMark, c.coinYear, cc.coinCategory, ct.coinType, c.coinName, c.coinVersion, c.coinMetal, c.strike, cc.denomination
        FROM coins c
            INNER JOIN cointypes ct ON ct.id = c.cointypes_id
            INNER JOIN coincategories cc ON cc.id = c.coincats_id
        WHERE c.id = ?';
    EXECUTE dynamic_statement USING c_id;
    DEALLOCATE PREPARE dynamic_statement;
END;

