create
    definer = root@localhost procedure CoinsGetByID(IN c_id int) comment 'Get coin by id.'
BEGIN
        DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1
                @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
             -- INSERT INTO error_log (error_num, error_message)
            SELECT @p1, @p2;
        END;
    DECLARE EXIT HANDLER FOR SQLWARNING
        BEGIN
            GET DIAGNOSTICS CONDITION 1
                @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
             -- INSERT INTO error_log (error_num, error_message)
            SELECT @p1, @p2;
        END;
        SELECT c.id, c.coinName, FuncCoinGetAllSubTypesByCoinId(c_id) AS sub_types, c.mintMark, c.coinYear, c.obv, c.rev, cc.coinCategory, ct.coinType, c.coinVersion, c.coinMetal, c.strike, cc.denomination,
               cc.id AS cat_id, ct.id AS type_id, c.byMint, c.byMintGold,

          CASE
                WHEN FuncCoinVarietyCountLabels(c_id, 'MMS') > 0 THEN FuncCoinGetAllLabelsByCoinId(4890, 'Mintmark Style')
                ELSE c.mms END AS mms
        FROM coins c
            INNER JOIN cointypes ct ON ct.id = c.cointypes_id
            INNER JOIN coincategories cc ON cc.id = c.coincats_id
        WHERE c.id = c_id;
END;

