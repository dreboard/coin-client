create definer = root@localhost view viewmoderncoins as
select `c`.`id`            AS `id`,
       `c`.`mintMark`      AS `mintMark`,
       `c`.`coinYear`      AS `coinYear`,
       `cc`.`coinCategory` AS `coinCategory`,
       `ct`.`coinType`     AS `coinType`,
       `c`.`coinName`      AS `coinName`,
       `c`.`coinVersion`   AS `coinVersion`,
       `c`.`coinMetal`     AS `coinMetal`,
       `c`.`strike`        AS `strike`,
       `ct`.`denomination` AS `denomination`
from ((`coins-test`.`coins` `c` join `coins-test`.`cointypes` `ct` on (`ct`.`id` = `c`.`cointypes_id`))
         join `coins-test`.`coincategories` `cc` on (`cc`.`id` = `c`.`coincats_id`))
where `c`.`coinYear` between 1965 and year(curdate())
order by `ct`.`denomination`;

