create definer = root@localhost view viewlincolnwheatbiecoins as
select `coins-test`.`coins`.`id`       AS `id`,
       `coins-test`.`coins`.`mintMark` AS `mintMark`,
       `coins-test`.`coins`.`coinYear` AS `coinYear`,
       `coins-test`.`coins`.`coinType` AS `coinType`,
       `coins-test`.`coins`.`coinName` AS `coinName`
from `coins-test`.`coins`
where `coins-test`.`coins`.`id` in
      ('7117', '7173', '7116', '7174', '7113', '7114', '7115', '7175', '7176', '7177', '7178', '7179', '7180', '7181',
       '7182', '7183', '7184', '7185', '7187', '7188', '7189', '7171', '7172')
order by `coins-test`.`coins`.`coinYear` desc;

