create
    definer = root@localhost procedure CommemorativeGetAll()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'commemoratives not found';
    SELECT * FROM coin_orm.coins WHERE coins.commemorative = 1
    ORDER BY denomination DESC;
  END;

