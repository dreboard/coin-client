create
    definer = root@localhost procedure CoinListDistinctSubTypeById(IN c_id int(10)) comment 'Get sub types by coinID.'
BEGIN
    IF EXISTS(SELECT DISTINCT (cv.sub_type) FROM coins_variety cv WHERE cv.coin_id = c_id and cv.sub_type != 'None')
    THEN
        SELECT DISTINCT (cv.sub_type)
        FROM coins_variety cv
        WHERE cv.coin_id = c_id
        ORDER BY udf_NaturalSortFormat(cv.variety, 15, ".");
    ELSE
        SELECT 0 AS sub_type;
    END IF;
END;

