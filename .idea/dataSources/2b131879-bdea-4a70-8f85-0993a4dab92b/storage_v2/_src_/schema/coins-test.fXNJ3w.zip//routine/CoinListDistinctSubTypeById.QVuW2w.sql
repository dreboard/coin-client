create
    definer = root@localhost procedure CoinListDistinctSubTypeById(IN c_id int(10)) comment 'Get sub types by coinID.'
BEGIN
      SELECT DISTINCT (cv.sub_type)
      FROM coins_variety cv
      WHERE cv.coin_id = c_id
      ORDER BY udf_NaturalSortFormat(cv.variety, 15, ".");
  END;

