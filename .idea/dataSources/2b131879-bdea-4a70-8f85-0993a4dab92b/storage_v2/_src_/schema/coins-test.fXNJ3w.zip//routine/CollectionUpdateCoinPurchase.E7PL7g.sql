create
    definer = root@localhost procedure CollectionUpdateCoinPurchase(IN co_id int, IN cp_col varchar(50), IN cp_val int)
    comment 'Save coin purchase'
BEGIN
  SET @sql = CONCAT('UPDATE `collected_purchase` SET', cp_col, ' = ',cp_val, ' WHERE `id` = ',co_id);
  PREPARE stmt FROM @sql;
  EXECUTE stmt;
  DEALLOCATE PREPARE stmt;
END;

