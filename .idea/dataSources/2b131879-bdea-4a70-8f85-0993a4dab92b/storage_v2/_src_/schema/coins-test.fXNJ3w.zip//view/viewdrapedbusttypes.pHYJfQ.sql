create view viewdrapedbusttypes as
select distinct `c`.`coinType` AS `coinType`, `c`.`cointypes_id` AS `cointypes_id`
from ((`coins-test`.`coins` `c` join `coins-test`.`cointypes` `ct` on (`c`.`cointypes_id` = `ct`.`id`))
         join `coins-test`.`coincategories` `cc` on (`cc`.`id` = `c`.`coincats_id`))
where `c`.`coinType` like 'Draped Bust%'
order by `cc`.`denomination`;

