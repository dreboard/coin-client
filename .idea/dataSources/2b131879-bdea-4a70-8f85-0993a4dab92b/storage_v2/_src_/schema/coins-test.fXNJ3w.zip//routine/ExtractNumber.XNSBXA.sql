create
    definer = root@localhost function ExtractNumber(in_string varchar(50)) returns int
BEGIN
    DECLARE ctrNumber VARCHAR(50);
    DECLARE finNumber VARCHAR(50) DEFAULT '';
    DECLARE sChar VARCHAR(1);
    DECLARE inti INTEGER DEFAULT 1;

    IF LENGTH(in_string) > 0 THEN
        WHILE (inti <= LENGTH(in_string))
            DO
                SET sChar = SUBSTRING(in_string, inti, 1);
                SET ctrNumber = FIND_IN_SET(sChar, '0,1,2,3,4,5,6,7,8,9');
                IF ctrNumber > 0 THEN
                    SET finNumber = CONCAT(finNumber, sChar);
                END IF;
                SET inti = inti + 1;
            END WHILE;
        RETURN CAST(finNumber AS UNSIGNED);
    ELSE
        RETURN 0;
    END IF;
END;

