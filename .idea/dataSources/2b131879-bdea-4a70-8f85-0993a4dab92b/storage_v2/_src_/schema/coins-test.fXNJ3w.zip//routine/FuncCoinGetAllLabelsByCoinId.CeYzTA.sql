create
    definer = root@localhost function FuncCoinGetAllLabelsByCoinId(c_id varchar(30), c_label varchar(50)) returns text
    comment 'Get count of different design types'
BEGIN
    DECLARE labelCount TEXT;
    SELECT GROUP_CONCAT(label SEPARATOR ', ')
    INTO labelCount
    FROM coins_variety WHERE coin_id = c_id AND variety = c_label;
    RETURN labelCount;
END;

