create
    definer = root@localhost procedure CollectionSaveCoin(IN u_id int(10), IN c_id int(100), IN cname varchar(50),
                                                          IN cgrade varchar(50), IN cprob int(1), IN cdamage int(1),
                                                          IN cvalue decimal(10, 2), IN cstatus int(100), IN cbox int(1),
                                                          IN cerror int(1), IN cdate datetime, IN cfirst int(1),
                                                          IN cvam varchar(50), IN csnow varchar(50),
                                                          IN cfs varchar(100), IN cfortin varchar(50),
                                                          IN csheldon varchar(50), IN cnewcomb varchar(50),
                                                          IN cwiley varchar(50), IN ccolor varchar(50),
                                                          IN cfull varchar(50), IN cmorgan varchar(50),
                                                          IN ctoned varchar(50), IN ctrail varchar(50),
                                                          IN cview varchar(50), IN clock int(1), IN cbie varchar(50),
                                                          IN cfrom varchar(255), IN purcdate datetime,
                                                          IN cprice decimal(10, 2), IN cebay varchar(255),
                                                          IN cshop varchar(255), IN c_url varchar(255),
                                                          IN c_damaged int(1), IN c_holed int(1), IN c_cleaned int(1),
                                                          IN c_altered int(1), IN c_scratched int(1), IN c_pvc int(1),
                                                          IN c_corrosion int(1), IN c_bent int(1), IN c_plugged int(1))
    comment 'Save users coin.'
BEGIN
    DECLARE new_id INT DEFAULT 0;
    DECLARE coin_id INT DEFAULT 0;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1
                @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
             -- INSERT INTO error_log (error_num, error_message)
            SELECT @p1, @p2;
            ROLLBACK;
        END;
    DECLARE EXIT HANDLER FOR SQLWARNING
        BEGIN
            GET DIAGNOSTICS CONDITION 1
                @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
             -- INSERT INTO error_log (error_num, error_message)
            SELECT @p1, @p2;
            ROLLBACK;
        END;
    START TRANSACTION;

    -- SET coin_id = (SELECT id FROM coins WHERE id = c_id LIMIT 1);
    SET coin_id = (SELECT COALESCE(id, 0)  FROM coins WHERE id = c_id LIMIT 1);

    IF EXISTS(SELECT id FROM coins WHERE id = c_id) THEN
        INSERT INTO collected
        (userID, coinID, coinNickname, coinGrade, problem, damaged, coinValue, sellStatus, mintBox, error, enterDate,
         firstday, vam, snow, fsNum, fortin, sheldon, newcomb, wileyBugert, color, fullAtt, morganDesignation, toned,
         trailDie, viewable, locked, bie)
        VALUES (u_id, c_id, cname, cgrade, cprob, cdamage, cvalue, cstatus, cbox, cerror, cdate, cfirst, cvam, csnow,
                cfs, cfortin, csheldon, cnewcomb, cwiley, ccolor, cfull, cmorgan, ctoned, ctrail, cview, clock, cbie);
        SET new_id = LAST_INSERT_ID();
        CALL CollectionSaveCoinPurchase(new_id, cfrom, purcdate, cprice, cebay, cshop, c_url, cfrom, cfrom);

        IF c_damaged = 1 THEN
            CALL CollectionSaveCoinDamage(new_id, c_holed, c_cleaned, c_altered, c_scratched, c_pvc, c_corrosion, c_bent, c_plugged);
        END IF;
        COMMIT;
    ELSE
        INSERT INTO error_log (error_num, error_message) VALUES ('c1000', 'Coin does not exist');
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Coin does not exist';
    END IF;

  END;

