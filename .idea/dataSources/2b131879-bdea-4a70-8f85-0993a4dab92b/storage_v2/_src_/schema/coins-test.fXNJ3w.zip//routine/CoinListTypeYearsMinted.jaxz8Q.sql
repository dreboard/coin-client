create
    definer = root@localhost procedure CoinListTypeYearsMinted(IN c_type int) comment 'Get coins year list.'
BEGIN
    SELECT DISTINCT(c.coinYear)
    FROM coins c
             INNER JOIN cointypes ct ON ct.id = c.cointypes_id
    WHERE ct.id = c_type
    ORDER BY c.coinYear;
END;

