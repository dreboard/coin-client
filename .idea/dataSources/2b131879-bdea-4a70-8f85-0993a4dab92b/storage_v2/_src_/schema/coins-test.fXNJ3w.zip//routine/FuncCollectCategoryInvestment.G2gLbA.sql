create
    definer = root@localhost function FuncCollectCategoryInvestment(c_cat int, u_id int(10)) returns decimal(10, 2)
    comment 'Returns total investment by category'
BEGIN
    DECLARE returnVal DECIMAL(10,3) DEFAULT 0.00;
    SELECT COALESCE(ROUND(sum(cp.purchasePrice), 2), 0.00)
    INTO returnVal
    FROM collected_purchase cp
             INNER JOIN collected co ON co.id = cp.collected_id
             INNER JOIN coins c ON co.coinID = c.id
             INNER JOIN coincategories cc ON cc.id = c.coincats_id
    WHERE co.userID = u_id
      AND cc.id = c_cat;
    RETURN returnVal; -- CAST(FORMAT(returnVal,2) AS DECIMAL(10, 2)); -- FORMAT(returnVal,2) ;
END;

