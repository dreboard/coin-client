create definer = root@localhost view viewallmintsets as
select `coins-test`.`mintset`.`mintsetID` AS `mintsetID`,
       `coins-test`.`mintset`.`setName`   AS `setName`,
       `coins-test`.`mintset`.`coinType`  AS `coinType`,
       `coins-test`.`mintset`.`coinYear`  AS `coinYear`
from `coins-test`.`mintset`
order by `coins-test`.`mintset`.`coinYear`;

