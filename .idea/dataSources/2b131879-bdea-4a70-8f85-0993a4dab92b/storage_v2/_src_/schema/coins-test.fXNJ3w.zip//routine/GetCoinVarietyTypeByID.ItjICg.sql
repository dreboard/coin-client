create
    definer = root@localhost procedure GetCoinVarietyTypeByID(IN c_variety varchar(30), IN c_id int(10))
    comment 'Get variety with same coinID.'
BEGIN
    SELECT cv.coneca, cv.designation, c.coinName FROM coins_variety cv
      INNER JOIN coins c ON c.id = cv.coin_id
    WHERE cv.coin_id = c_id AND cv.variety = c_variety
      ORDER BY udf_NaturalSortFormat(cv.coneca, 10, ".");
  END;

