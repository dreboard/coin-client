create
    definer = root@localhost procedure CollectionGetCoinsByID(IN coin int(10), IN id int(10))
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLWARNING BEGIN END;
    SELECT * FROM coin_orm.collection
      INNER JOIN coin_orm.coins ON coin_orm.coins.coinID = coin_orm.collection.coinID
    WHERE collection.coinID = coin AND collection.userID = id;

  END;

