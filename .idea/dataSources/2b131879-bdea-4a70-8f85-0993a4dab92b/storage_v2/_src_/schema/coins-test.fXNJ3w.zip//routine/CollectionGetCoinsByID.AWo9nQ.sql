create
    definer = root@localhost procedure CollectionGetCoinsByID(IN coin int(10), IN id int(10))
BEGIN
    DECLARE CONTINUE HANDLER FOR SQLWARNING BEGIN END;
    SELECT * FROM collection
      INNER JOIN coins ON coins.coinID = collection.coinID
    WHERE collection.coinID = coin AND collection.userID = id;

  END;

