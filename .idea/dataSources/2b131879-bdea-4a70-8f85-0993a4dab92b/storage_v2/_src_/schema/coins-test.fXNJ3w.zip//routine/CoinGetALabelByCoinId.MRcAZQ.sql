create
    definer = root@localhost procedure CoinGetALabelByCoinId(IN c_id int, IN c_label varchar(50))
    comment 'Get all labels by coin id'
BEGIN
    SELECT GROUP_CONCAT(CONCAT(sub_type, ' '), label SEPARATOR ', ') FROM coins_variety WHERE coin_id = c_id AND variety = c_label;
END;

