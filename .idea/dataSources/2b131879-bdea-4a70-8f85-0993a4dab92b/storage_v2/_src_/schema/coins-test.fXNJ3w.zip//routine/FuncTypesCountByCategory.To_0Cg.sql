create
    definer = root@localhost function FuncTypesCountByCategory(c_cat int) returns int
    comment 'Count of types by category'
BEGIN
    DECLARE c_types VARCHAR(30);
    IF c_cat IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Category cant be blank';
    END IF;
    SELECT COUNT(coinType)
    INTO c_types
    FROM cointypes
    WHERE coincats_id = c_cat;
    RETURN c_types;
END;

