create
    definer = root@localhost procedure CoinListSubCategoryAll() comment 'List of subcategories'
BEGIN
    SELECT DISTINCT(coinSubCategory) FROM coins;
  END;

