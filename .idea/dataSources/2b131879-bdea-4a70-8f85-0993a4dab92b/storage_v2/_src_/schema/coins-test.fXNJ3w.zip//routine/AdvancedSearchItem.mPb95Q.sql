create
    definer = root@localhost procedure AdvancedSearchItem(IN searchItem varchar(100), IN searchCategory varchar(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'Item not found';
    SELECT * FROM coins WHERE coinName LIKE CONCAT('%', searchItem , '%')
    ORDER BY coinName ASC;
  END;

