create
    definer = root@localhost function FuncCoinTypeCountByCategory(c_cat int) returns int
BEGIN
    DECLARE typesCollected INT;
    SELECT COUNT(ct.coincats_id) INTO typesCollected FROM cointypes ct
    WHERE ct.coincats_id = c_cat AND LEFT(ct.coinType, 5) != 'Mixed';
    RETURN typesCollected;
  END;

