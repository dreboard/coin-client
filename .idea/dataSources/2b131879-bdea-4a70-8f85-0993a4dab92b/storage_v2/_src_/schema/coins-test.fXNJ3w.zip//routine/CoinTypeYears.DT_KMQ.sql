create
    definer = root@localhost procedure CoinTypeYears(IN type varchar(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'dates not found';
    SELECT dates FROM cointypes
    WHERE coinType = type;
  END;

