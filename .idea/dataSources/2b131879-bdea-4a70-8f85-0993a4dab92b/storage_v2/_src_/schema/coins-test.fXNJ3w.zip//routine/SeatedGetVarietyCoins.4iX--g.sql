create
    definer = root@localhost procedure SeatedGetVarietyCoins(IN seated_variety varchar(50), IN c_type int)
    comment 'Set cointype field'
BEGIN
    SELECT DISTINCT c.id, cv.sub_type, c.coinSubCategory, c.coinName, c.coinYear, c.mintMark, c.coinVersion, c.designType, c.obv, c.obv2, c.rev, c.rev2
        FROM coins c
        INNER JOIN coincategories cc ON cc.id = c.coincats_id
        INNER JOIN coins_variety cv ON cv.coin_id = c.id
        WHERE
              cv.sub_type = seated_variety
        -- MATCH(cv.sub_type) AGAINST(seated_variety IN BOOLEAN MODE )
       AND c.cointypes_id = c_type ORDER BY c.coinYear;
  END;

