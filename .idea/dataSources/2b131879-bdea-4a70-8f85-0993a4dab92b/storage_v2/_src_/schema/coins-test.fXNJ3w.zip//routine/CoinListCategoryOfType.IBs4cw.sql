create
    definer = root@localhost procedure CoinListCategoryOfType(IN c_type varchar(100))
    comment 'Get category from coin Type'
BEGIN
    SELECT cc.coinCategory FROM cointypes ct
    INNER JOIN coincategories cc ON cc.id = ct.coincats_id
    WHERE ct.id = c_type;
  END;

