create
    definer = root@localhost function FuncGetCentury(c_year int(4)) returns int
BEGIN
    DECLARE the_century INT;
    RETURN CEIL(c_year/100);
  END;

