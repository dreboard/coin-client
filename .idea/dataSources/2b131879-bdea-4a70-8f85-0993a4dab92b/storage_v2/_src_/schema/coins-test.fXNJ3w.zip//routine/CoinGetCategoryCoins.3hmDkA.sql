create
    definer = root@localhost procedure CoinGetCategoryCoins(IN c_cat int)
BEGIN
    SELECT c.id, c.coinName, ct.coinType, c.coinYear, c.coinVersion, cc.coinCategory
    FROM coins c
             INNER JOIN cointypes ct ON c.cointypes_id = ct.id
             INNER JOIN coincategories cc ON cc.id = c.coincats_id
    WHERE c.coincats_id = c_cat
    ORDER BY cc.denomination, ct.id;
END;

