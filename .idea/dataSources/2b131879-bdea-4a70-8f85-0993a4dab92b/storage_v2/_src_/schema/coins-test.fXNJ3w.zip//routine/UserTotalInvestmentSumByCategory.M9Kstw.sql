create
    definer = root@localhost procedure UserTotalInvestmentSumByCategory(IN id int, IN cat varchar(100), IN purchaseFrom varchar(100))
BEGIN
    -- Collection::getTotalInvestmentSumByCategoryFrom()
    SELECT COALESCE(sum(purchasePrice), 0.00)
    FROM collection
      INNER JOIN coins ON collection.coinID = coins.coinID
    WHERE collection.userID = id
          AND coins.coinCategory = cat
          AND collection.purchaseFrom = purchaseFrom;
  END;

