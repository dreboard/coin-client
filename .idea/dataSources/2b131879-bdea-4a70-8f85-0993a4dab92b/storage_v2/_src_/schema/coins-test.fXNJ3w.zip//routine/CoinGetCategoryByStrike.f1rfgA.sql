create
    definer = root@localhost procedure CoinGetCategoryByStrike(IN c_cat int, IN c_strike varchar(20))
BEGIN
    SELECT c.id, c.coinName, ct.coinType, c.coinYear, c.coinVersion, cc.coinCategory
    FROM coins c
             INNER JOIN cointypes ct ON c.cointypes_id = ct.id
             INNER JOIN coincategories cc ON cc.id = c.coincats_id
    WHERE c.coincats_id = c_cat AND c.strike = c_strike
    ORDER BY cc.denomination, ct.id;
END;

