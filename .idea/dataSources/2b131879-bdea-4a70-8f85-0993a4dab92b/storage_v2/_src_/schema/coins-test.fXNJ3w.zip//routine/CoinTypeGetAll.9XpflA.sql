create
    definer = root@localhost procedure CoinTypeGetAll(IN c_type int) comment 'Get all coin Type coins'
BEGIN
    SELECT c.id,
           c.mintMark,
           c.coinYear,
           cc.coinCategory,
           ct.coinType,
           c.coinName,
           c.coinVersion,
           c.coinMetal,
           c.strike,
           cc.denomination
    FROM coins c
             INNER JOIN cointypes ct ON ct.id = c.cointypes_id
             INNER JOIN coincategories cc ON cc.id = c.coincats_id
    WHERE ct.id = c_type

    ORDER BY CASE ct.releaseType WHEN 0 THEN c.coinYear END DESC,
             CASE ct.releaseType WHEN 1 THEN c.release END ASC;
END;

