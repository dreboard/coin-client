create
    definer = root@localhost procedure DesignGetCoinType(IN design varchar(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'Design not found';
    SELECT coinType FROM coin_orm.coins WHERE coins.designType = design LIMIT 1;
  END;

