create definer = root@localhost event EventReplicateCoinsTable on schedule
    at '2019-10-20 22:26:36'
    on completion preserve
    disable
    comment 'Copy coins table daily backup'
    do
    CALL ReplicateCoinsTable();

