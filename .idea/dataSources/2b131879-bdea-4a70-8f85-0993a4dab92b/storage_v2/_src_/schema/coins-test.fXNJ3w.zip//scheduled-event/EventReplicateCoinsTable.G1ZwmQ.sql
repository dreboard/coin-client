create definer = root@localhost event EventReplicateCoinsTable on schedule
    at '2019-09-14 00:36:45'
    on completion preserve
    enable
    do
    CALL ReplicateCoinsTable();

