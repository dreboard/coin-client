create
    definer = root@localhost function FuncCoinGetAllSubTypesByCoinId(c_id int) returns text
    comment 'Get count of different design types'
BEGIN
    DECLARE SubTypesCount TEXT;
    SELECT GROUP_CONCAT(DISTINCT sub_type SEPARATOR ', ')
    INTO SubTypesCount
    FROM coins_variety WHERE coin_id = c_id;
    RETURN SubTypesCount;
END;

