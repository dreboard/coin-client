create
    definer = root@localhost procedure CategoryCollectedCountByUser(IN cat varchar(20), IN id int)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT '0';
    SELECT COUNT(*) AS catCount FROM collection
      INNER JOIN coins ON collection.coinID = coins.coinID
    WHERE collection.userID = id
          AND coins.coinCategory = cat;
  END;

