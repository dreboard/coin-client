create
    definer = root@localhost function FuncCollectionCountCoinByGrade(u_id int, c_id varchar(20), co_grade varchar(10)) returns int
BEGIN
    DECLARE gradesCollected INT;
    SELECT COUNT(co.coinGrade) INTO gradesCollected FROM collected co
    WHERE co.coinGrade = co_grade AND co.coinID = c_id AND co.userID = u_id ;
    RETURN gradesCollected;
  END;

