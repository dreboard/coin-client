create definer = root@localhost view viewdistinctdesigntypes as
select distinct `coins-test`.`coins`.`designType` AS `designType`
from `coins-test`.`coins`
where `coins-test`.`coins`.`designType` <> 'None'
  and `coins-test`.`coins`.`designType` <> ''
order by `coins-test`.`coins`.`designType`;

