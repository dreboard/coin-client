create
    definer = root@localhost procedure UserAllCollectedCoins(IN id int) comment 'Get a count of all collected coins'
BEGIN
    SELECT COUNT(*) FROM collection WHERE userID = id;
  END;

