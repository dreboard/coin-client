create
    definer = root@localhost procedure CoinGetAllTypesFromYear(IN c_year int) comment 'Get coins all same year.'
BEGIN
    SELECT DISTINCT(ct.coinType)
        FROM cointypes ct
            INNER JOIN coins c ON c.cointypes_id = ct.id
            INNER JOIN coincategories cc ON cc.id = ct.coincats_id
    WHERE c.coinYear  = c_year
    ORDER BY cc.denomination;
END;

