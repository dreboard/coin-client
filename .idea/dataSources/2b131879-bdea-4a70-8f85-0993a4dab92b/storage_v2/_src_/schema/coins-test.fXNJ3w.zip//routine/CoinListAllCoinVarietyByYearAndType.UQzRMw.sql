create
    definer = root@localhost procedure CoinListAllCoinVarietyByYearAndType(IN c_type int(10), IN c_year int(10), IN c_var varchar(20))
    comment 'Get variety list by year and type'
BEGIN
    SELECT DISTINCT(cv.variety)
    FROM coins_variety cv
             INNER JOIN coins c ON cv.coin_id = c.id
             INNER JOIN cointypes ct ON c.cointypes_id = ct.id
             INNER JOIN coincategories cc ON cc.id = ct.coincats_id
    WHERE c.coinYear = c_year
      AND c.cointypes_id = c_type
      -- AND cv.variety = c_var
    ORDER BY cc.denomination;

END;

