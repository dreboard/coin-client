create
    definer = root@localhost procedure CoinGetAllProofTypeFromYear(IN c_year int, IN c_type int)
    comment 'Get Commemorative all same year.'
BEGIN
    SELECT c.id, c.coinName, c.coinType, c.coinYear, c.coinVersion
        FROM coins c
        INNER JOIN coincategories cc ON cc.id = c.coincats_id
        WHERE c.coinYear = c_year AND c.cointypes_id = c_type AND c.strike IN ('Proof', 'Reverse Proof')  ORDER BY cc.denomination;

END;

