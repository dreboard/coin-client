create
    definer = root@localhost procedure UserAllUniqueCollectedCoins(IN id int)
BEGIN
    -- Collection::getCollectionCountById()
    SELECT COUNT(DISTINCT coinID) FROM collection WHERE userID = id;
  END;

