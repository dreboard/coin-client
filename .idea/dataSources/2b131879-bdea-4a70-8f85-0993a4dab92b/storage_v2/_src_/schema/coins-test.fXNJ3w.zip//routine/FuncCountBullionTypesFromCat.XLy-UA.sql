create
    definer = root@localhost function FuncCountBullionTypesFromCat(c_cat int) returns int
    comment 'Count All Bullion coin types by category'
BEGIN
    DECLARE typesCollected INT;

    SELECT COUNT(DISTINCT ct.coinType) INTO typesCollected FROM coins c
    INNER JOIN cointypes ct ON ct.id = c.cointypes_id
	INNER JOIN coincategories cc ON cc.id = c.coincats_id
    WHERE c.coincats_id = c_cat
    AND c.coinMetal IN ('Gold', 'Platinum', 'Palladium');
    RETURN typesCollected;
  END;

