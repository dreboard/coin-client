create
    definer = root@localhost procedure CollectionGetCoin(IN c_id int, IN u_id int(10))
    comment 'Get users collected coin.'
BEGIN
    SELECT co.*, c.id, c.mintMark, c.coinYear, cc.coinCategory, ct.coinType, c.coinName, c.coinVersion, c.coinMetal, c.strike, cc.denomination
	FROM collected co
	INNER JOIN coins c ON c.id = co.coinID
	INNER JOIN cointypes ct ON ct.id = c.cointypes_id
	INNER JOIN coincategories cc ON cc.id = c.coincats_id
    WHERE co.id = c_id AND co.userID = u_id
    LIMIT 1;
  END;

