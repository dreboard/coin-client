create
    definer = root@localhost procedure CollectionGetCoin(IN c_id int, IN u_id int(10))
    comment 'Get users collected coin.'
BEGIN
    SELECT
       CASE
            WHEN cv.sub_type != 'None' THEN CONCAT(c.coinName, " ", COALESCE(cv.sub_type, ''))
            ELSE c.coinName
        END AS coinName,
           COALESCE(GROUP_CONCAT(DISTINCT cv.label ORDER BY cv.label ASC SEPARATOR ', '), 'None') AS varieties,
           co.*
           , c.id, c.mintMark, c.coinYear, cc.coinCategory, ct.coinType, c.coinVersion, c.coinMetal, c.strike, cc.denomination,
           clp.purchasePrice
	FROM collected co
	INNER JOIN coins c ON c.id = co.coinID
	LEFT JOIN collected_variety clv ON co.id = clv.collected_id
	LEFT JOIN collected_purchase clp ON co.id = clp.collected_id
	LEFT JOIN collected_img cli ON co.id = cli.collected_id
	LEFT JOIN collected_damage cld ON co.id = cld.collected_id
	LEFT JOIN coins_variety cv ON clv.coins_variety_id = cv.id
	INNER JOIN cointypes ct ON ct.id = c.cointypes_id
	INNER JOIN coincategories cc ON cc.id = c.coincats_id
    WHERE co.id = c_id AND co.userID = u_id
    LIMIT 1;
  END;

