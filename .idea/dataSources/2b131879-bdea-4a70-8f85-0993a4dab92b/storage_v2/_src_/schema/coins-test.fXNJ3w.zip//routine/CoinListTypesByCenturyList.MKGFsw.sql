create
    definer = root@localhost procedure CoinListTypesByCenturyList(IN c_year int)
    comment 'List of types same decade 1900.'
BEGIN
    SELECT DISTINCT(ct.coinType)
        FROM cointypes ct
            INNER JOIN coins c ON c.cointypes_id = ct.id
            INNER JOIN coincategories cc ON cc.id = ct.coincats_id
    WHERE c.coinYear LIKE CONCAT(SUBSTRING(c_year,1, 2), '%')
    ORDER BY cc.denomination;
END;

