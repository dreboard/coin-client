create
    definer = root@localhost procedure InsertVamListByID(IN c_id int)
BEGIN

		SET @vamList = '
		VAM-1 8TF Doubled E,
		VAM-2 8TF Doubled Reverse,
		VAM-2A 8TF Doubled Reverse, Clashed Obverse In & t, Reverse M,
		VAM-3 8TF Doubled Reverse,
		VAM-4 8TF Doubled Date,
		VAM-4A 8TF Doubled Date, Clashed Obverse n & t,
		VAM-5 8TF Doubled Motto,
		VAM-6 8TF Doubled Motto,
		VAM-7 8TF Spiked A,
		VAM-8 8TF Stick Feather,
		VAM-9 8TF First Morgan Dollar, Comma Feather Reverse ,
		VAM-9A 8TF First Morgan Dollar, Comma Feather Reverse, Clashed Obverse n & t,
		VAM-10 8TF Doubled Motto,
		VAM-10A 8TF Doubled Motto, Polishing Lines Lower Reverse,
		VAM-12 8TF Doubled Motto,
		VAM-14 8TF Chip in Ear, Doubled Motto,
		VAM-14A 8TF Doubled Motto, Clashed Obverse n,
		VAM-14.1 8TF Doubled Eye FrontPCGS NGCvam-horz.jpg,
		VAM-14.1A 8TF Doubled Eye Front, Clashed Obverse n,
		VAM-14.2 8TF Polished Ear,Doubled Date, Tripled Left Stars,
		VAM-14.2A 8TF Polished Ear,Doubled Date, Tripled Left Stars, Feed Finger Gouges OF,
		VAM-14.2B 8TF Polished Ear,Doubled Date, Tripled Left Stars, Feed Finger Gouges & Break OF,
		VAM-14.3 8TF Doubled Reverse,
		VAM-14.4 8TF Concave Field,
		VAM-14.4A 8TF Concave Fields, Clashed Obverse In & t,
		VAM-14.5 8TF Spiked "A",
		VAM-14.6 8TF Dot on ear,
		VAM-14.6A 8TF Dot on ear, Die Break Star,
		VAM-14.7 8TF Dot Next to Ear,
		VAM-14.8 8TF Doubled Eyelid,
		VAM-14.9 8TF Tripled Eyelid,
		VAM-14.10 8TF Doubled Lower Hair and Date,
		VAM-14.11 8TF Wild Eye Spikes,
		VAM-14.11A 8TF, Wild Eye Spike, Die Break,
		VAM-14.12 8TF Double Date,
		VAM-14.12A 8TF Double Date, Radial Die Breaks Stars,
		VAM-14.13 8TF Bar Eyelid,
		VAM-14.14 8TF Double LIBERTY,
		VAM-14.15 8TF Doubled Motto,
		VAM-14.16 8TF Doubled Profile and Tripled Date,
		VAM-14.16A 8TF Doubled Profile and Tripled Date, Die Break Right Dot,
		VAM-14.17 8TF Doubled Date and Hair,
		VAM-14.18 8TF Doubled Eyelid,
		VAM-14.19 8TF Doubled LI-ERTY,
		VAM-14.20 8TF Tripled Date & Right Stars,
		VAM-15 8TF Doubled Liberty concave reverse,
		VAM-16 8TF Doubled Liberty,
		VAM-17 8TF Doubled Reverse,
		VAM-18 8TF Doubled Date,
		VAM-18A 8TF Doubled Date, Clashed Obverse n,
		VAM-19 8TF Doubled Date,
		VAM-20 8TF Doubled Date, Clashed Obverse n,
		VAM-21 8TF Doubled B,
		VAM-22A 8TF Doubled LIBERTY, Clashed Obserse n & t,
		VAM-22B 8TF Doubled LIBERTY, Clashed Obverse n & t, Die Breaks Wing Tip,
		VAM-22C 8TF Doubled LIBERTY, Clashed Obverse n & t, Die Breaks Wing Tip, Left Stars & One,
		VAM-23 8TF Doubled Eagles Beak';
        SET @i = 1;
		WHILE (LOCATE(',', @vamList) > 0)

		DO
			SET @value = ELT(@i, @vamList);
			SET @vamList= SUBSTRING(@vamList, LOCATE(',',@vamList) + 1);

			INSERT INTO `coin_vam`(coin_id, designation) VALUES(3224, @value);
			SET @i = @i+1;
		END WHILE;
  
  END;

