create definer = root@localhost view allplatinumcategories as
select distinct `coin_orm`.`coins`.`coinCategory` AS `coinCategory`
from `coin_orm`.`coins`
where `coin_orm`.`coins`.`coinMetal` = 'Platinum'
order by `coin_orm`.`coins`.`denomination` desc;

